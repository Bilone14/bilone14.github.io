rootProject.name = "BiloneTV"
include(":app")
