package com.bilone.tv

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val btnOpen = findViewById<Button>(R.id.btnOpen)
        val etUrl = findViewById<EditText>(R.id.etUrl)
        val etUser = findViewById<EditText>(R.id.etUser)
        val etPass = findViewById<EditText>(R.id.etPass)

        btnOpen.setOnClickListener {
            val url = etUrl.text.toString().trim()
            val user = etUser.text.toString().trim()
            val pass = etPass.text.toString().trim()
            if (url.isEmpty()) {
                AlertDialog.Builder(this)
                    .setTitle("Erreur")
                    .setMessage("Veuillez entrer votre lien Xtream")
                    .setPositiveButton("OK", null)
                    .show()
                return@setOnClickListener
            }

            val prefs = getSharedPreferences("bilone_prefs", MODE_PRIVATE)
            prefs.edit().putString("xtream_url", url)
                .putString("xtream_user", user)
                .putString("xtream_pass", pass).apply()

            try {
                val intent = Intent(Intent.ACTION_VIEW, Uri.parse(url))
                startActivity(intent)
            } catch (e: Exception) {
                AlertDialog.Builder(this)
                    .setTitle("Erreur")
                    .setMessage("Impossible d'ouvrir l'URL : ${e.message}")
                    .setPositiveButton("OK", null)
                    .show()
            }
        }
    }
}
